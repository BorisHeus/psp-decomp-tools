#!/bin/sh
# check.sh - bundle self-test: compiles and disassembles a known function.
PSPC="$(cd "$(dirname "$0")" && pwd)"
OUT="$("$PSPC/mm" "$PSPC/cand/selftest.c" 2>/dev/null)"
echo "$OUT" | grep -q "jr  *\$ra" && { echo "BUNDLE-OK: wibo+mwcc b192+mipsdis all working"; exit 0; }
echo "BUNDLE-FAIL:"; echo "$OUT"; exit 1
