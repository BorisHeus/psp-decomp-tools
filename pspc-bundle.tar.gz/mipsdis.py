import struct, sys
REG = ["zero","at","v0","v1","a0","a1","a2","a3","t0","t1","t2","t3","t4","t5","t6","t7",
       "s0","s1","s2","s3","s4","s5","s6","s7","t8","t9","k0","k1","gp","sp","fp","ra"]
R = lambda i: "$"+REG[i&31]
SPECIAL = {0x00:"sll",0x02:"srl",0x03:"sra",0x04:"sllv",0x06:"srlv",0x07:"srav",
           0x08:"jr",0x09:"jalr",0x0A:"movz",0x0B:"movn",0x0D:"break",
           0x10:"mfhi",0x11:"mthi",0x12:"mflo",0x13:"mtlo",0x18:"mult",0x19:"multu",
           0x1A:"div",0x1B:"divu",0x21:"addu",0x22:"sub",0x23:"subu",
           0x24:"and",0x25:"or",0x26:"xor",0x27:"nor",0x2A:"slt",0x2B:"sltu"}
SPECIAL2 = {0x02:"mul",0x20:"clz",0x21:"clo"}
REGIMM = {0x00:"bltz",0x01:"bgez",0x02:"bltzl",0x03:"bgezl",0x10:"bltzal",0x11:"bgezal",0x12:"bltzall",0x13:"bgezall"}
OP = {0x02:"j",0x03:"jal",0x04:"beq",0x05:"bne",0x06:"blez",0x07:"bgtz",
      0x08:"addi",0x09:"addiu",0x0A:"slti",0x0B:"sltiu",0x0C:"andi",0x0D:"ori",
      0x0E:"xori",0x0F:"lui",0x14:"beql",0x15:"bnel",
      0x20:"lb",0x21:"lh",0x23:"lw",0x24:"lbu",0x25:"lhu",
      0x28:"sb",0x29:"sh",0x2B:"sw",0x30:"ll",0x38:"sc"}
COP1_MOVE = {0x00:"mfc1",0x04:"mtc1",0x02:"cfc1",0x06:"ctc1"}
def dis(w):
    if w == 0: return "nop"
    op = w >> 26
    rs = (w >> 21) & 31; rt = (w >> 16) & 31
    imm = w & 0xFFFF; simm = imm - 0x10000 if imm & 0x8000 else imm
    if op == 0:
        funct = w & 0x3F; rd = (w >> 11) & 31; sa = (w >> 6) & 31
        name = SPECIAL.get(funct, "SPECIAL?%02x" % funct)
        if funct in (0,2,3): return f"{name} {R(rd)}, {R(rt)}, {sa}"
        if funct == 8: return f"jr {R(rs)}"
        if funct == 9: return f"jalr {R(rd)}, {R(rs)}"
        if funct in (0x10,0x12): return f"{name} {R(rd)}"
        if funct in (0x11,0x13): return f"{name} {R(rs)}"
        if funct in (0x18,0x19,0x1A,0x1B): return f"{name} {R(rs)}, {R(rt)}"
        return f"{name} {R(rd)}, {R(rs)}, {R(rt)}"
    if op == 0x1C:
        funct = w & 0x3F; rd = (w >> 11) & 31
        return f"{SPECIAL2.get(funct, 'SPECIAL2?%02x' % funct)} {R(rd)}, {R(rs)}"
    if op == 0x1F:
        funct = w & 0x3F; rd = (w >> 11) & 31; sa = (w >> 6) & 31
        if funct == 0x00: return f"ext {R(rt)}, {R(rs)}, {sa}, {rd + 1}"  # FIX 2026-10-31 (entry 92): EXT rd = msbd = size-1, INDEPENDENT of lsb (old formula rd-sa+1 = the INS rule, printed -1 for lsb>0; ext $2,$2,16,15 = 0x7C427400)
        if funct == 0x04: return f"ins {R(rt)}, {R(rs)}, {sa}, {rd - sa + 1}"
        return f"SPECIAL3?{funct:#x}"
    if op == 0x01:
        n = REGIMM.get((w >> 16) & 31, "REGIMM?")
        return f"{n} {R(rs)}, {(simm<<2)&0xFFFFFFFF:#x}"
    if op == 0x11:
        sub = (w >> 21) & 31; fs = (w >> 11) & 31
        if sub in COP1_MOVE: return f"{COP1_MOVE[sub]} {R(rt)}, $f{fs}"
        if sub == 0x08:
            BC = {0:"bc1f",1:"bc1t",2:"bc1fl",3:"bc1tl"}
            return f"{BC.get(rt,'bc1?')} {(simm<<2)&0xFFFFFFFF:#x}"
        FMT = {0x10:"s",0x11:"d",0x14:"w",0x15:"l"}
        fn = w & 0x3F; fd = (w >> 6) & 31; ft = rt
        CONV = {0x08:"round.l",0x09:"trunc.l",0x0A:"ceil.l",0x0B:"floor.l",
                0x0C:"round.w",0x0D:"trunc.w",0x0E:"ceil.w",0x0F:"floor.w"}
        if fn in CONV:
            return f"{CONV[fn]}.{FMT[sub]} $f{fd}, $f{fs}"
        ARITH = {0x00:"add",0x01:"sub",0x02:"mul",0x03:"div",0x04:"sqrt",0x05:"abs",0x06:"mov",0x07:"neg"}
        if fn in ARITH:
            return f"{ARITH[fn]}.{FMT[sub]} $f{fd}, $f{fs}"
        if fn in (0x20,0x21,0x24,0x25):
            CVT2 = {0x20:"cvt.s",0x21:"cvt.d",0x24:"cvt.w",0x25:"cvt.l"}
            return f"{CVT2[fn]}.{FMT[sub]} $f{fd}, $f{fs}"
        COND = {0x30:"c.f",0x31:"c.un",0x32:"c.eq",0x33:"c.ueq",0x34:"c.olt",0x35:"c.ult",0x36:"c.ole",0x37:"c.ule",0x38:"c.sf",0x39:"c.ngle",0x3A:"c.seq",0x3B:"c.ngl",0x3C:"c.lt",0x3D:"c.nge",0x3E:"c.le",0x3F:"c.ngt"}
        if fn in COND:
            return f"{COND[fn]}.{FMT[sub]} $f{fs}, $f{ft}"
        return f"cop1 {w:#010x}"
    if op == 0x31: return f"lwc1 $f{rt}, {simm}({R(rs)})"
    if op == 0x39: return f"swc1 $f{rt}, {simm}({R(rs)})"
    if op == 0x35: return f"ldc1 $f{rt}, {simm}({R(rs)})"
    if op == 0x3D: return f"sdc1 $f{rt}, {simm}({R(rs)})"
    if op in OP:
        n = OP[op]
        if n in ("lb","lh","lw","lbu","lhu","sb","sh","sw","ll","sc"):
            return f"{n} {R(rt)}, {simm}({R(rs)})"
        if n == "lui": return f"lui {R(rt)}, {imm:#x}"
        if n in ("j","jal"): return f"{n} {((w & 0x3FFFFFF) << 2) & 0xFFFFFFFF:#x}"
        if n in ("beq","bne","beql","bnel"): return f"{n} {R(rs)}, {R(rt)}, {(simm<<2)&0xFFFFFFFF:#x}"
        if n in ("blez","bgtz"): return f"{n} {R(rs)}, {(simm<<2)&0xFFFFFFFF:#x}"
        if n in ("addi","addiu"): return f"{n} {R(rt)}, {R(rs)}, {simm}"
        if n == "slti": return f"slti {R(rt)}, {R(rs)}, {simm}"
        if n == "sltiu": return f"sltiu {R(rt)}, {R(rs)}, {simm}"
        if n in ("andi","ori","xori"): return f"{n} {R(rt)}, {R(rs)}, {imm:#x}"
    return f".word {w:#010x}"
def parse_elf(path):
    data = open(path, "rb").read()
    assert data[:4] == b"\x7fELF" and data[4] == 1, "not ELF32 LE"
    (e_type, e_machine, e_version, e_entry, e_phoff, e_shoff, e_flags,
     e_ehsize, e_phentsize, e_phnum, e_shentsize, e_shnum, e_shstrndx) = struct.unpack_from("<HHIIIIIHHHHHH", data, 16)
    secs = []
    for i in range(e_shnum):
        off = e_shoff + i * e_shentsize
        (sh_name, sh_type, sh_flags, sh_addr, sh_offset, sh_size, sh_link, sh_info,
         sh_addralign, sh_entsize) = struct.unpack_from("<10I", data, off)
        secs.append(dict(name_off=sh_name, type=sh_type, addr=sh_addr, offset=sh_offset,
                         size=sh_size, link=sh_link, info=sh_info, entsize=sh_entsize))
    shstr = secs[e_shstrndx]
    def sname(s):
        start = shstr["offset"] + s["name_off"]
        end = data.index(b"\0", start)
        return data[start:end].decode()
    for s in secs: s["name"] = sname(s)
    return data, secs
def symbols(path):
    data, secs = parse_elf(path)
    out = {}
    for s in secs:
        if s["type"] == 2:
            strs = secs[s["link"]]
            n = s["size"] // s["entsize"]
            for i in range(n):
                off = s["offset"] + i * 16
                (st_name, st_value, st_size, st_info, st_other, st_shndx) = struct.unpack_from("<IIIBBH", data, off)
                start = strs["offset"] + st_name
                end = data.index(b"\0", start)
                name = data[start:end].decode()
                if name and st_shndx != 0:
                    out[name] = (st_value, st_size)
    return out
def func_words(path, name):
    data, secs = parse_elf(path)
    syms = symbols(path)
    if name not in syms:
        cands = [k for k in syms if k.startswith(name)]
        if not cands: return None
        name = cands[0]
    addr, size = syms[name]
    if size == 0: size = 0x1000
    for s in secs:
        if s["type"] == 1 and s["name"] == ".text":
            off = s["offset"] + (addr - s["addr"])
            if size <= s["size"]:
                return list(struct.unpack_from("<%dI" % (size // 4), data, off))
    for s in secs:
        if s["type"] == 1 and s["addr"] <= addr and addr + size <= s["addr"] + s["size"]:
            off = s["offset"] + (addr - s["addr"])
            return list(struct.unpack_from("<%dI" % (size // 4), data, off))
    return None
def relocs(path):
    """va -> list of (rtype, symbol_name) for .text relocs only (skips .rel.pdr etc.)."""
    data, secs = parse_elf(path)
    all_syms = {}
    for s in secs:
        if s["type"] == 2:
            strs = secs[s["link"]]
            for i in range(s["size"] // s["entsize"]):
                off = s["offset"] + i * 16
                (st_name, st_value, st_size, st_info, st_other, st_shndx) = struct.unpack_from("<IIIBBH", data, off)
                p = strs["offset"] + st_name
                all_syms[i] = data[p:data.index(b"\0", p)].decode()
    out = {}
    for s in secs:
        # ONLY .text relocs: .rel.pdr carries a reloc against the function symbol that pollutes sequences
        if s["type"] == 9 and s.get("info") is not None and secs[s["info"]]["name"] == ".text":
            tgt = secs[s["info"]]
            for i in range(s["size"] // 8):
                (r_offset, r_info) = struct.unpack_from("<II", data, s["offset"] + i * 8)
                # ET_REL: r_offset is SECTION-RELATIVE (sh_addr is 0 in .o files) — do NOT subtract sh_offset
                out.setdefault(tgt["addr"] + r_offset, []).append((r_info & 0xFF, all_syms.get(r_info >> 8, "?")))
    return out

if __name__ == "__main__":
    path, fn = sys.argv[1], sys.argv[2]
    w = func_words(path, fn)
    if not w: print("not found"); sys.exit(1)
    for i, x in enumerate(w):
        print(f"{fn}+{i*4:04x}  {x:08x}  {dis(x)}")
