# pspc-bundle - prebuilt mwcc b192 matching environment (KB fast path)

Contents:
  wibo        (decompals/wibo 1.2.0, x86_64)
  mwcc/       (mwccpsp 3.0.1 build 192, from decompme/compilers releases)
  mipsdis.py  (KB mipsdis disassembler, from tooling.md section 5)
  mm          compile+disassemble wrapper
  check.sh    self-test
  cand/selftest.c

One-line setup in a fresh chat sandbox:
  mkdir -p ~/pspc && curl -sL <BUNDLE-URL> | tar xz -C ~/pspc && ~/pspc/check.sh

Usage:
  ~/pspc/mm cand/x.c [symbol]        compile (-c -O3 -sdatathreshold 0) + disasm
  MMFLAGS="-O4,p" ~/pspc/mm x.c      extra/replacement mwcc flags
  symbol defaults to the file basename without .c

KB facts that still apply:
  - compile ONE function per file (mwcc .o has one .text per function, symbols 0)
  - MWCIncludes warning is noise
  - extra compiler rungs (SNC, psp-gcc, other mwcc builds) stay on demand per
    environment.md; this bundle only carries the ~90% fast path (b192).

Built 2026-11-01.
