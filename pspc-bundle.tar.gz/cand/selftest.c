int selftest(int a, int b) {
    if (a > b) return a * 3 + b;
    return a + b * 7;
}
